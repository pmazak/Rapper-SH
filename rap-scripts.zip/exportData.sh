#  Exports some data as comma-delimited
#  <numRows>
#  100
echo "Exporting data..."
echo "Done."