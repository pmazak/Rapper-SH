#  Runs the log grepper job
#  <regex> (<maxNumMatches>)
#  .+ABC.+
echo "Finding lines matching ${1}..."
echo "Done."